#ifndef _CHECK_CHECK_STDINT_H
#define _CHECK_CHECK_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "check 0.14.0"
/* generated using gnu compiler Apple clang version 11.0.0 (clang-1100.0.33.12) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
